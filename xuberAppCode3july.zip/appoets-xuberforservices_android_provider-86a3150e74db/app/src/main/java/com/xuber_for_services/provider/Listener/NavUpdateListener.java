package com.xuber_for_services.provider.Listener;


public interface NavUpdateListener {
    public void onProfileUpdateReflect();
}
