package com.xuber_for_services.provider.Utils;

/**
 * Created by RAJKUMAR on 17-05-2017.
 */

public class Keyname {
    public static final String EDIT_PROFILE = "edit_profile";
    public static final String ACCESS_TOKEN = "access_token";
}
