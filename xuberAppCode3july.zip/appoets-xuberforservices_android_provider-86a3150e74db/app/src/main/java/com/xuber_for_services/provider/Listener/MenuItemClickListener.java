package com.xuber_for_services.provider.Listener;

import android.view.MenuItem;

/**
 * Created by RAJKUMAR on 10-04-2017.
 */
public interface MenuItemClickListener {
    public void onMenuItemClick(MenuItem item, Object object);
}
